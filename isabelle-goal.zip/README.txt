To run the files install and open Isabelle from https://isabelle.in.tum.de/

The primary file to open is "Gvf_Example_BW4T.thy".
Please allow some time for the theories to be checked.
Isabelle will load and check all of the required files which can then be browsed.